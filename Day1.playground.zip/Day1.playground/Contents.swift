import Cocoa

var greeting = "Hello, playground"


print(greeting)

var name = "Ted"

name = "Reb"

name = "Keeley"

let character = "Daphne"

var playerName = "Roy"
print(playerName)

playerName = "Dani"
print(playerName)

playerName = "Sam"
print(playerName)

let managerName = "Michael Scott"
let dogBreed = "Pitty"
let meaningOfLife = "How many Roads?"


let actor = "Denzel"

let quote = "Then he tapped a sign sayins \"Believe\" and walked away."

let movie = """
A day in
the life of an
Apple engineer
"""

print(actor.count)

print(movie.hasPrefix("A day"))

let score = 10

let reallyBig = 100_000_000

let lowerscore = score - 2
let higherScore = score + 10
let doubleScore = score * 2

var counter = 10
counter = counter + 5
counter += 5
print(counter)
counter *= 2
counter -= 10

let number = 120
print(number.isMultiple(of: 3))

let newNumber  = 0.1 + 0.2
print(newNumber)

let a = 1
let b = 2.0
let c = a + Int(b)

let double1 = 3.1
let double2 = 3131.3131
let double3 = 3.0
let int1 = 3

var NewNickName = "Nick Cage"

var rating = 5.0
rating *= 2
print (rating)






